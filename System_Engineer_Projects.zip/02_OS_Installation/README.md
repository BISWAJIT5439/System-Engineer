# 02 OS Installation

Automated scripts for Windows/Linux OS installation.
