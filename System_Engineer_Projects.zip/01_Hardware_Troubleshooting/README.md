# 01 Hardware Troubleshooting

Script and documentation for diagnosing hardware issues.
