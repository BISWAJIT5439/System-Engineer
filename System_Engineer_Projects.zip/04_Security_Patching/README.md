# 04 Security Patching

Scripts and README for patching OS vulnerabilities.
