# 05 Active Directory Management

Scripts for managing AD users, groups, and permissions.
